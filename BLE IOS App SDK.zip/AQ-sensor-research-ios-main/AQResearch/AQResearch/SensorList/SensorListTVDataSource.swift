//
//  SensorListTVCDelegate.swift
//  AQResearch
//
//  Created by Aaron on 11/26/19.
//  Copyright © 2019 Procter & Gamble. All rights reserved.
//

import Foundation
import ResearchBit
import UIKit
import CoreLocation

class SensorListTVDataSource: NSObject, UITableViewDataSource {

    @Storage(key: Constants.Keys.UserDefaults.sensorList, defaultValue: [])
    var sensors: [Sensor]
    weak var tableView: UITableView?
    
    var logger: Logger? = Constants.logger
    
    init(tableView: UITableView?) {
        self.tableView = tableView
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if PGAuth.shared.authState != .signedIn || sensors.count == 0 {
            return 1
        } else {
            return sensors.count
        }
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if PGAuth.shared.authState == .signedIn {
            if sensors.count > 0 {
                let cell = tableView.dequeueReusableCell(withIdentifier: Constants.CellIdentifiers.statusCell, for: indexPath) as! StatusCell
                cell.selectionStyle = .none
                
                let sensor = sensors[indexPath.item]

                cell.configure(with: sensor)

                return cell
            } else {
                return getLabelCell(text: Constants.Text.noSensorsCellText)
            }
        } else {
            return getLabelCell(text: Constants.Text.logInCellText)
        }
    }

    private func getLabelCell(text: String) -> UITableViewCell {
        let cell = UITableViewCell()
        cell.selectionStyle = .none
        cell.textLabel?.text = text
        cell.textLabel?.textAlignment = .center
        return cell
    }
//    
//    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
//        switch PGAuth.shared.authState {
//        case .signedIn:
//            return true
//        default:
//            return false
//        }
//    }
//    
//    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
//        if editingStyle == .delete {
//            sensors.remove(at: indexPath.row)
//            tableView.deleteRows(at: [indexPath], with: .fade)
//        }
//    }
    
    func add(device: BLEDevice) {
        
        logger?.write("Adding BLE Device: \(device.debugDescription)")
        
        if !sensors.compactMap({ $0.uuid }).contains(device.peripheral.identifier) {
            
            let bp: BeaconParameters? = BeaconParameters(uuid: device.iBeaconUUID,
                                                         major: CLBeaconMajorValue(device.iBeaconMajor),
                                                         minor: CLBeaconMinorValue(device.iBeaconMinor),
                                                         identifier: "\(device.deviceName ?? "device")-\(device.iBeaconMajor)-\(device.iBeaconMinor)")
            
//            #warning("Get Beacon from BLEDevice instead of random from TestData")
//            if device.deviceName == "ResBit" {
//                bp = TestData.resbitBeacon
//                logger?.write("Using hard-coded Resbit Beacon: \(bp.debugDescription)")
//            } else if sensors.count < TestData.beaconList.count {
//                bp = TestData.beaconList[sensors.count]
//                logger?.write("Using test beacon: \(bp.debugDescription)")
//            }

            sensors.append(Sensor(device: device, beaconParameters: bp))

            if let bp = bp {
                Scanner.shared.startScanning(forBeacon: bp)
            }
        }
        tableView?.reloadData()
    }
}
