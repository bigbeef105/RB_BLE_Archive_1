//
//  MQTTPayload.swift
//  AQResearch
//
//  Created by Aaron on 2/17/20.
//  Copyright © 2020 Procter & Gamble. All rights reserved.
//

import Foundation
import ResearchBit

/// The payload that is sent to AWS MQTT
struct MQTTPayload: Codable {
    /// The User's Study ID
    let studyId: String?
    /// The user's Participant ID
    let participantId: String?
    /// The Summary Data provided by the BLEDevice/ResearchBit SDK
    let summaryData: SummaryData
    /// Serial ID of the BLE Device
    let sensorSerialId: String?
    
    var debugDescription: String {
        return "\(studyId ?? "nil") / \(participantId ?? "nil") / \(summaryData.debugDescription)"
    }
    
}
