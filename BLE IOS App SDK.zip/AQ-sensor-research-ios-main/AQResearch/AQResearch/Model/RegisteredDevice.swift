//
//  RegisteredDevice.swift
//  AQResearch
//
//  Created by Aaron on 1/28/20.
//  Copyright © 2020 Procter & Gamble. All rights reserved.
//

import Foundation

/// A device registered to a user
struct RegisteredDevice: Identifiable, Codable {
    /// The ID of the device, created by the device manufacturer
    var id: UUID
    /// The name of the device, pulled from the AWS endpoint
    var name: String
    
    init(id: UUID, name: String) {
        self.id = id
        self.name = name
    }

    init(id: String, name: String) {
        self.id = UUID(uuidString: id)!
        self.name = name
    }
    
}
