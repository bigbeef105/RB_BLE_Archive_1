//
//  Analytics.swift
//  AQResearch
//
//  Created by Aaron on 2/10/20.
//  Copyright © 2020 Procter & Gamble. All rights reserved.
//

import Foundation
import FirebaseAnalytics
import CoreLocation
import CoreBluetooth
import ResearchBit

protocol LoggedEvent {
    var rawValue: String { get }
    func log()
}

extension LoggedEvent {
    func log() {
        Event.logEvent(self.rawValue, parameters: [:])
    }
}

/// An event to be logged through Firebase Analytics
struct Event {
    
    /// Log the event
    /// - Parameters:
    ///   - name: Event Name
    ///   - parameters: Parameters for the event
    fileprivate static func logEvent(_ name: String, parameters: [String: Any]?) {
        
        DispatchQueue.global(qos: .background).async {
            
            PGAuth.shared.getUserAttributes { result in
                switch result {
                case .success(let attributes):
                    var newParams = parameters ?? [:]
                    newParams["aws_username"] = attributes.sub
                    Analytics.logEvent(name, parameters: newParams)
                case .failure:
                    Analytics.logEvent(name, parameters: parameters)
                }
            }
        }
        
    }
    
    /// Lifecycle Events
    enum Lifecycle: String, LoggedEvent {
        case applicationLaunched = "application_launched"
    }
    
    /// Account Events
    enum Account: LoggedEvent {
        case signUp
        case confirmAccount
        case resendConfirmationCode
        case login
        case logout
        case showEULA
        
        var rawValue: String {
            switch self {
            case .signUp: return "user_sign_up"
            case .confirmAccount: return "user_confirm_account"
            case .resendConfirmationCode: return "user_resend_confirmation_code"
            case .login: return "user_login"
            case .logout: return "user_logout"
            case .showEULA: return "user_show_eula"
            }
        }
        
        func log() {
            switch self {
            default:
                Event.logEvent(self.rawValue, parameters: [:])
            }
        }
    }

    ///Beacon Events
    enum Beacon: LoggedEvent {
        case beganMonitoring(region: BeaconParameters)
        case stoppedMonitoring
        case monitoringFailed
        case enteredRegion(region: CLBeaconRegion)
        case exitedRegion(region: CLBeaconRegion)
        case authorizationStatus(status: CLAuthorizationStatus)
        
        var rawValue: String {
            switch self {
            case .beganMonitoring: return "bb_began_monitoring"
            case .stoppedMonitoring: return "bb_stopped_monitoring"
            case .monitoringFailed: return "bb_monitoring_failed"
            case .enteredRegion: return "bb_entered_region"
            case .exitedRegion: return "bb_exited_region"
            case .authorizationStatus: return "ble_allow_status"
            }
        }
        
        func log() {
            switch self {
            case let .beganMonitoring(beacon): Event.logEvent(self.rawValue, parameters: ["beacon_uuid": beacon.uuid.uuidString, "beacon_major": beacon.major, "beacon_minor": beacon.minor])
            case let .enteredRegion(region):
                var uuid: UUID
                if #available(iOS 13.0, *) {
                    uuid = region.uuid
                } else {
                    uuid = region.proximityUUID
                }
                Event.logEvent(self.rawValue, parameters: ["beacon_uuid": uuid.uuidString, "beacon_major": region.major as? Int ?? -1, "beacon_minor": region.minor as? Int ?? -1])
            case let .exitedRegion(region):
                var uuid: UUID
                if #available(iOS 13.0, *) {
                    uuid = region.uuid
                } else {
                    uuid = region.proximityUUID
                }
                Event.logEvent(self.rawValue, parameters: ["beacon_uuid": uuid.uuidString, "beacon_major": region.major as? Int ?? -1, "beacon_minor": region.minor as? Int ?? -1])
            case let .authorizationStatus(status): Event.logEvent(self.rawValue, parameters: ["status": status.description])
            default:
                Event.logEvent(self.rawValue, parameters: [:])
            }
        }
    }

    /// Bluetooth Device Events
    enum BluetoothDevice: LoggedEvent {
        case scan
        case connectSuccess
        case connectFailure
        case noData
        case addedDevice
        case managerState(state: CBManagerState)
        
        var rawValue: String {
            switch self {
            case .scan: return "ble_scan"
            case .connectSuccess: return "ble_connect_success"
            case .connectFailure: return "ble_connect_failure"
            case .noData: return "ble_no_data"
            case .addedDevice: return "ble_added_device"
            case .managerState: return "ble_manager_state"
            }
        }
        
        func log() {
            switch self {
            case let .managerState(state):
                Event.logEvent(self.rawValue, parameters: ["state": state.description])
            default:
                Event.logEvent(self.rawValue, parameters: [:])
            }
        }
    }
    
    /// AWS Events
    enum AWS: LoggedEvent {
        case loginSuccess
        case loginFailure
        case logoutSuccess
        case logoutFailure
        case writeMQTTSuccess
        case writeMQTTFailure
        case provisionSuccess
        case provisionFailure
        
        var rawValue: String {
            switch self {
            case .loginSuccess: return "aws_login_success"
            case .loginFailure: return "aws_login_failure"
            case .logoutSuccess: return "aws_logout_success"
            case .logoutFailure: return "aws_logout_failure"
            case .writeMQTTSuccess: return "aws_write_mqtt_success"
            case .writeMQTTFailure: return "aws_write_mqtt_failure"
            case .provisionSuccess: return "aws_provision_success"
            case .provisionFailure: return "aws_provision_failure"
            }
        }
        
        func log() {
            switch self {
            default:
                Event.logEvent(self.rawValue, parameters: [:])
            }
        }
    }
}
