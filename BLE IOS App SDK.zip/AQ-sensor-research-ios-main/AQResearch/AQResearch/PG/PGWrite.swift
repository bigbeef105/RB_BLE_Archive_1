//
//  PGWrite.swift
//  AQWritePOC
//
//  Created by Aaron on 11/7/19.
//  Copyright © 2019 Alchemy. All rights reserved.
//

import Foundation
import AWSIoT
import ResearchBit

/// Errors for PGWrite
enum PGWriteError: Error {
    case MQTTWriteError(message: String)
    case MQTTConnectError(message: String)
    case MQTTNotConnectedError
    case NotLoggedInError
    
    var localizedDescription: String {
        switch self {
        case let .MQTTWriteError(message): return "MQTTWriteError: \(message)"
        case let .MQTTConnectError(message): return "MQTTConnectError: \(message)"
        case .MQTTNotConnectedError: return "MQTTNotConnectedError: MQTT Connection not established"
        case .NotLoggedInError: return "NotLoggedInError: User is not logged in"
        }
    }
}

/// A singleton class to handle writing data to P&G's AWS services
///
/// Accessed via the `shared` property
///
class PGWrite {
    
    /// Endpoint where MQTT messages will be sent when retrieved from the BLE devices
    fileprivate static let IoTEndpoint = Constants.PGWrite.iotEndpoint
    /// Data Manager Key used by the AWSIoTDataManager.
    fileprivate static let DataManagerKey = Constants.PGWrite.dataManagerKey
    /// AWS App Client Id, defined in AWS Console -> Cognito -> [User Pool] -> General Settings -> App Clients
    fileprivate static let AppClientId = Constants.PGWrite.appClientId
    /// AWS Identity Pool ID, defined in AWS Console -> Cognito -> [Identity Pool] -> Identity Pool ID
    fileprivate static let IdentityPoolId = Constants.PGWrite.identityPoolId
    
    /// The shared instance
    static let shared = PGWrite()

    /// The logger to use
    var logger: Logger?
    /// The AWS IoT Data Manager
    fileprivate var dataManager: AWSIoTDataManager?

    /// Initializes the AWS IoT MQTT connection information
    fileprivate init() {
        let endpoint = AWSEndpoint(urlString: PGWrite.IoTEndpoint)
        let credentialsProvider = PGAuth.shared.awsMobileClient
        if let dataConfiguration = AWSServiceConfiguration(region:.USEast1, endpoint: endpoint, credentialsProvider: credentialsProvider) {
            AWSServiceManager.default().defaultServiceConfiguration = dataConfiguration
            AWSIoTDataManager.register(with: dataConfiguration, forKey: PGWrite.DataManagerKey)
            dataManager = AWSIoTDataManager(forKey: PGWrite.DataManagerKey)
        }

        dataManager?.register(withShadow: "research_bit_test1", options: nil, eventCallback: { (str, opType, stType, str2, data) in
            self.logger?.write("\(#function) - Register Callback: \(str):\(opType):\(stType):\(str2):\(String(bytes: data, encoding: .utf8) ?? "nil")")
        })

        logger = Constants.logger
    }

    /// Configures the logger to be used by PGWrite
    func configure(logger: Logger) {
        self.logger = logger
    }
    
    /// Connects to AWS IoT MQTT via Web Sockets
    func connect(auth: PGAuth = PGAuth.shared, completion: @escaping (AWSIoTMQTTStatus?, Error?) -> Void) {
        
        guard let dataManager = dataManager else {
            self.logger?.write("*****\nNo dataManager!\n*****")
            completion(nil, PGWriteError.MQTTConnectError(message: "dataManager not configured"))
            return
        }
        
        let credentialsTask = dataManager.configuration.credentialsProvider.credentials()
        let identityIdTask  = PGAuth.shared.awsMobileClient.getIdentityId()
        
        credentialsTask.waitUntilFinished()
        identityIdTask.waitUntilFinished()
        
        let credentials = credentialsTask.result
        let identityId  = identityIdTask.result
        
        logger?.write("---------------------")
        logger?.write("Identity Id: \(identityId ?? "nil")")
        logger?.write("Credentials: \(credentials?.accessKey ?? "nil")")
        logger?.write("---------------------")
        
        let success1 = dataManager.connectUsingWebSocket(withClientId: PGWrite.AppClientId, cleanSession: true) { status in
            self.logger?.write("***** Web Socket Connection callback status = \(status.description)")
            switch status {
            case .connected:
                completion(status, nil)
            case .connecting:
                completion(status, nil)
            case .disconnected:
                completion(status, nil)
            case .unknown:
                completion(status, nil)
            case .connectionError:
                completion(status, PGWriteError.MQTTConnectError(message: "Connection failed with status 1: \(status.description)"))
            case .connectionRefused:
                completion(status, PGWriteError.MQTTConnectError(message: "Connection failed with status 2: \(status.description)"))
            case .protocolError:
                completion(status, PGWriteError.MQTTConnectError(message: "Connection failed with status 3: \(status.description)"))
            default:
                completion(status, nil)
            }
        }
        logger?.write("Finished Web Socket connect - success: \(success1)")
    }
    
    /// Writes summary data to AWS IoT
    ///
    /// Note: The completion is called after all requests are made - not after the responses are received
    ///
    /// - Parameters:
    ///   - summaryData: A collection of SummaryData elements to write
    ///   - completion: Executed after all data is written to AWS
    func writeSummaryData(summaryData: [SummaryData], sensor: Sensor, completion: @escaping (Result<Void, Error>) -> Void) {
        
        let logger = self.logger
                
        PGAuth.shared.getUserAttributes { (result) in
            
            switch result {
            case let .failure(error):
                logger?.write("   Error getting user attributes: \(error.localizedDescription)")
            case let .success(attributes):
                
                let studyId: String? = attributes.studyId
                let participantId: String? = attributes.participantId

                let topic = PGMqttThingTopic.data(studyId: attributes.studyId ?? "unknown", participantId: attributes.participantId ?? "unknown")
//                let topic = PGMqttThingTopic.test

                
                
                //BEGIN Do one post for EACH summaryData item (MQTTPayload.summaryData should be type SummaryData)
                for data in summaryData {

                    let mqttPayload = MQTTPayload(studyId: studyId, participantId: participantId, summaryData: data, sensorSerialId: sensor.serialId)

                    logger?.write("Sending MQTT Payload: \(mqttPayload.debugDescription)")

                    do {
                        let jsonData = try JSONEncoder().encode(mqttPayload)
                        logger?.write("Writing to AWS")
                        logger?.write("   Topic: \(topic.getTopic())", channel: "MQTT")
                        logger?.write("    Data: \(String(bytes: jsonData, encoding: .utf8) ?? "nil")", channel: "MQTT")

                        PGWrite.shared.connectAndWrite(to: topic, payload: String(bytes: jsonData, encoding: .utf8)!) { (result) in
                            switch result {
                            case .success:
                                logger?.write("         Success", channel: "MQTT")
                            case .failure(let error):
                                logger?.write("         Error: \(error.localizedDescription)", channel: "MQTT")
                            }
                        }
                    } catch {
                        logger?.write("Error writing to MQTT: \(error.localizedDescription)")
                    }
                }
                //END Do one post for EACH summaryData item

                // BEGIN Do one post to MQTT with all summaryData (MQTTPayload.summaryData should be type [SummaryData])
//                let mqttPayload = MQTTPayload(studyId: studyId, participantId: participantId, summaryData: summaryData, sensorSerialId: sensor.serialId ?? sensor.name)
//
//                logger?.write("Sending MQTT Payload: \(mqttPayload.debugDescription)")
//
//                do {
//                    let jsonData = try JSONEncoder().encode(mqttPayload)
//                    logger?.write("Writing to AWS")
//                    logger?.write("   Topic: \(topic.getTopic())", channel: "MQTT")
//                    logger?.write("    Data: \(String(bytes: jsonData, encoding: .utf8) ?? "nil")", channel: "MQTT")
//
//                    PGWrite.shared.connectAndWrite(to: topic, payload: String(bytes: jsonData, encoding: .utf8)!) { (result) in
//                        switch result {
//                        case .success:
//                            logger?.write("         Success", channel: "MQTT")
//                        case .failure(let error):
//                            logger?.write("         Error: \(error.localizedDescription)", channel: "MQTT")
//                        }
//                    }
//                } catch {
//                    logger?.write("Error writing to MQTT: \(error.localizedDescription)")
//                }
                // END Do one post to MQTT with all summaryData
                
                
                completion(.success(()))
                
            }
        }
    }
    
    /// Returns `true` if PGWrite is currently connected to the AWS IoT MQTT service
    func isConnected() -> Bool {
        guard let dataManager = dataManager else {
            logger?.write("No dataManager!")
            return false
        }
        
        let connection = dataManager.getConnectionStatus()
        
        guard connection == .connected else {
            logger?.write("\(#function): Not connected: \(connection.description)")
            return false
        }
        
        return true
    }
    
    /// Connects to MQTT service if needed and then calls `writeData` to write `payload` to the given AWT IoT MQTT topic.
    ///
    /// Leaves connection in its original state - connected if previously connected, disconnects if not originally connected.
    /// - Parameters:
    ///   - topic: Topic to post `payload` to
    ///   - responseTopics: Optional. Will subscribe to the response topics and execute the responseCompletion for the same index. The response completions are not currently implemented.
    ///   - payload: The payload to send to AWS
    ///   - auth: The PGAuth instance to use. Defaults to the shared instance.
    ///   - responseCompletions: Not currently implemented.
    ///   - completion: Called after the data write is successful or fails
    func connectAndWrite(to topic: PGMqttThingTopic, responseTopics: [PGMqttThingTopic] = [], payload: String, auth: PGAuth = PGAuth.shared, responseCompletions: Array<(Data) -> Void> = [], completion: @escaping (Result<Void, Error>) -> Void) {

        guard responseTopics.count == responseCompletions.count else {
            completion(.failure(PGWriteError.MQTTWriteError(message: "Response Topics count (\(responseTopics.count)) and Response Completions count (\(responseCompletions.count)) are not equal.")))
            return
        }

        if !isConnected() {
            connect { (status, error) in
                
                if let error = error {
                    completion(.failure(error))
                    return
                }
                
                switch status {
                case .connected: ()
                self.writeData(to: topic, responseTopics: responseTopics, payload: payload) { result in
                    completion(result)
                }
                case .connectionError:
                    completion(.failure(error ?? PGWriteError.MQTTConnectError(message: "Error connecting to MQTT service (1)")))
                case .connectionRefused: ()
                    completion(.failure(error ?? PGWriteError.MQTTConnectError(message: "Error connecting to MQTT service (2)")))
                case .protocolError: ()
                    completion(.failure(error ?? PGWriteError.MQTTConnectError(message: "Error connecting to MQTT service (3)")))
                case .connecting: ()
                case .disconnected: ()
                default: ()
                }
            }
        } else {
            writeData(to: topic, responseTopics: responseTopics, payload: payload, completion: completion)
        }
    }

    /// Writes `payload` to the provided AWS IoT MQTT topic.
    ///
    /// Leaves connection in its original state - connected if previously connected, disconnects if not originally connected.
    /// - Parameters:
    ///   - topic: Topic to post `payload` to
    ///   - responseTopics: Optional. Will subscribe to the response topics and execute the responseCompletion for the same index. The response completions are not currently implemented.
    ///   - payload: The payload to send to AWS
    ///   - auth: The PGAuth instance to use. Defaults to the shared instance.
    ///   - responseCompletions: Not currently implemented.
    ///   - completion: Called after the data write is successful or fails
    private func writeData(to topic: PGMqttThingTopic, responseTopics: Array<PGMqttThingTopic> = [], payload: String, auth: PGAuth = PGAuth.shared, responseCompletions: Array<(Data) -> Void> = [], completion: (Result<Void, Error>) -> Void) {
        
        guard responseTopics.count == responseCompletions.count else {
            completion(.failure(PGWriteError.MQTTWriteError(message: "Response Topics count (\(responseTopics.count)) and Response Completions count (\(responseCompletions.count)) are not equal.")))
            return
        }
        
        guard isConnected() else {
            completion(.failure(PGWriteError.MQTTNotConnectedError))
            return
        }
        guard let dataManager = dataManager else {
            completion(.failure(PGWriteError.MQTTWriteError(message: "dataManager not configured")))
            return
        }
        
        for (responseTopic, responseCompletion) in zip(responseTopics, responseCompletions) {
            dataManager.subscribe(toTopic: responseTopic.getTopic(), qoS: .messageDeliveryAttemptedAtLeastOnce) { (data) in
                responseCompletion(data)
            }
        }
        
        logger?.write("Writing Data - status: \(dataManager.getConnectionStatus().rawValue)")
        
        let success = dataManager.publishString(payload, onTopic: topic.getTopic(), qoS:.messageDeliveryAttemptedAtLeastOnce)
        logger?.write("Published to topic: \(success)")
        
        let status = dataManager.getConnectionStatus()
        logger?.write("Connection Status (last): \(status.description)")
        
        completion(.success(()))
        
    }
    
    /// Disconnects from AWS IoT MQTT service
    private func disconnect() {
        let connection = dataManager?.getConnectionStatus()
        if let dataManager = dataManager, connection == .connected || connection == .connecting {
            dataManager.disconnect()
        } else {
            logger?.write("Not connected: \(connection != nil ? connection!.description : "nil")")
        }
    }
}
