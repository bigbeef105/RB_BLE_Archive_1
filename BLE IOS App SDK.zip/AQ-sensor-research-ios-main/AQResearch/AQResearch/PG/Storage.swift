//
//  DefaultsProperty.swift
//  AQResearch
//
//  Created by Aaron on 11/26/19.
//  Copyright © 2019 Procter & Gamble. All rights reserved.
//
//  Code copied from Medium post:
//  https://medium.com/better-programming/create-the-perfect-userdefaults-wrapper-using-property-wrapper-42ca76005ac8
//

import Foundation

@propertyWrapper
/// Stores and Retrieves the value from UserDefaults
struct Storage<T: Codable> {
    /// The UserDefaults Key
    private let key: String
    /// The default value to use if UserDefaults does not have a value
    private let defaultValue: T
    
    /// Stores and retrieves the value from UserDefaults
    /// - Parameters:
    ///   - key: The UserDefaults Key
    ///   - defaultValue: The default value to use if UserDefaults does not have a value
    init(key: String, defaultValue: T) {
        self.key = key
        self.defaultValue = defaultValue
    }

    var wrappedValue: T {
        get {
            // Read value from UserDefaults
            guard let data = UserDefaults.standard.object(forKey: key) as? Data else {
                // Return defaultValue when no data in UserDefaults
                return defaultValue
            }

            // Convert data to the desire data type
            let value = try? JSONDecoder().decode(T.self, from: data)
            return value ?? defaultValue
        }
        set {
            // Convert newValue to data
            let data = try? JSONEncoder().encode(newValue)

            // Set value to UserDefaults
            UserDefaults.standard.set(data, forKey: key)
        }
    }
}
