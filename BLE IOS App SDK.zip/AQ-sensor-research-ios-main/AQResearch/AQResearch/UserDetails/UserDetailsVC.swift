//
//  UserDetailsVC.swift
//  AQResearch
//
//  Created by Aaron on 1/7/20.
//  Copyright © 2020 Procter & Gamble. All rights reserved.
//

import UIKit
import SVProgressHUD

class UserDetailsVC: UIViewController {

    @IBOutlet weak var usernameLabel: UILabel!
    @IBOutlet weak var verifiedImage: UIImageView!
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    @IBOutlet weak var verifiedMessageLabel: UILabel!
    @IBOutlet weak var studyIdLabel: UILabel!
    @IBOutlet weak var participantIdLabel: UILabel!

    var logger: Logger? = Constants.logger

    override func viewDidLoad() {
        super.viewDidLoad()

        self.activityIndicator.hidesWhenStopped = true

        activityIndicator.startAnimating()
        PGAuth.shared.getUserAttributes { (result) in

            defer {
                DispatchQueue.main.async {
                    self.activityIndicator.stopAnimating()
                }
            }

            switch result {
            case let .failure(error):
                self.logger?.write("Error getting user attributes: \(error.localizedDescription)")
            case let .success(attributes):
                DispatchQueue.main.async {

                    self.usernameLabel.textColor = .black
                    self.usernameLabel.text = attributes.email

                    self.studyIdLabel.textColor = .black
                    self.studyIdLabel.text = attributes.studyId ?? "Unknown"

                    self.participantIdLabel.textColor = .black
                    self.participantIdLabel.text = attributes.participantId ?? "Unknown"

                    if attributes.emailVerified {
                        self.verifiedImage.image = Constants.Images.Login.Colored.emailVerified
                    } else {
                        self.verifiedImage.image = Constants.Images.Login.Colored.emailUnverified
                    }
                }
            }
        }
    }
    
    @IBAction func showEula(_ sender: Any) {
        performSegue(withIdentifier: "showEula", sender: self)
    }
    
    @IBAction func logout(_ sender: Any) {
        self.presentConfirmationDialog(title: "Log Out?",
                                       message: "Are you sure you want to log out?",
                                       okIsDestructive: false) { (action) in
            DispatchQueue.main.async { SVProgressHUD.show(withStatus: "Logging out...") }
            DispatchQueue.global(qos: .background).async {
                PGAuth.shared.signOut() { error in
                    if error != nil {
                        self.logger?.write("Error logging out: \(error!)")
                    }

                    DispatchQueue.main.async {
                        SVProgressHUD.dismiss()
                        self.navigationController?.popViewController(animated: true)
                    }
                    
                }
            }
        }
    }
    
    @IBAction func showTroubleshooting(_ sender: Any) {

//        #warning("Remove this and re-enable the code")
//        self.performSegue(withIdentifier: "troubleshootingSegue", sender: self)
        
        let alert = UIAlertController(title: "Restricted", message: "Enter the Administrative Code", preferredStyle: .alert)
        alert.addTextField { (textField) in
            textField.isSecureTextEntry = true
            textField.keyboardType = .namePhonePad
        }


        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { [weak alert] (_) in
            let textField = alert!.textFields![0] // Force unwrapping because we know it exists.
            let code = textField.text?.lowercased()
            if code == Constants.Text.Troubleshooting.secretCode {
                self.performSegue(withIdentifier: "troubleshootingSegue", sender: self)
            } else {
                self.logger?.write("Invalid admin code: \(code ?? "nil")")
                SVProgressHUD.showErrorAndDismiss(withStatus: "Invalid code")
            }
        }))

        self.present(alert, animated: true, completion: nil)
    }
}
