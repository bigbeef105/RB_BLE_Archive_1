//
//  EulaVC.swift
//  AQResearch
//
//  Created by Aaron on 1/7/20.
//  Copyright © 2020 Procter & Gamble. All rights reserved.
//

import UIKit
import WebKit

class EulaVC: UIViewController {

    @IBOutlet weak var webView: WKWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        webView.load(URLRequest(url: Constants.eulaUrl))
        Event.Account.showEULA.log()
    }

    @IBAction func dismissEula(_ sender: Any) {
        self.dismiss(animated: true)
    }
}
