//
//  TroubleshootingViewController.swift
//  AQResearch
//
//  Created by Aaron on 1/10/20.
//  Copyright © 2020 Procter & Gamble. All rights reserved.
//

import UIKit
import SVProgressHUD

class TroubleshootingVC: UIViewController {

    var logger: Logger? = Constants.logger
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var descriptionLabel: UILabel!
    
    @IBOutlet weak var forceCrashButton: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        titleLabel.text = Constants.Text.Troubleshooting.title
        descriptionLabel.text = Constants.Text.Troubleshooting.description
    }
    
    @IBAction func resetBeaconMonitoring(_ sender: Any) {
        SVProgressHUD.show(withStatus: "Resetting Beacon Monitoring...")
        
        logger?.write("Resetting Beacon Monitoring...")
        Scanner.shared.stopScanning()

        logger?.write("Monitoring stopped.")
        Scanner.shared.startScanning()

        logger?.write("Monitoring started.")

        SVProgressHUD.showSuccessAndDismiss(withStatus: "Done!")

    }
    
    @IBAction func removeAllSensors(_ sender: Any) {

        SVProgressHUD.show(withStatus: "Clearing Sensors...")
        
        logger?.write("Stopping monitor for beacons...")
        Scanner.shared.stopScanning()

        logger?.write("Removing all sensors from memory...")
        UserDefaults.standard.removeObject(forKey: Constants.Keys.UserDefaults.sensorList)

        logger?.write("Done.")
        
        SVProgressHUD.showSuccessAndDismiss(withStatus: "Done!")
    }
    
    @IBAction func sendTestMQTTMessage(_ sender: Any) {
        SVProgressHUD.show(withStatus: "Sending 5 test messages simultaneously...")
        for idx in 0...5 {
            DispatchQueue.global(qos: .background).asyncAfter(deadline: .now() + Double(idx)) {
                PGWrite.shared.connectAndWrite(to: .test, payload: #"{ "message": "Test MQTT Message" }"#) { result in
                    switch result {
                    case .success():
                        self.logger?.write("Successfully wrote to MQTT.")
                        SVProgressHUD.showSuccessAndDismiss(withStatus: "Success!")
                    case .failure(let error):
                        if let error = error as? PGWriteError {
                            self.logger?.write("Error writing to MQTT: \(error.localizedDescription)")
                            SVProgressHUD.showErrorAndDismiss(withStatus: "Error: \(error.localizedDescription)", delay: 6)
                        } else {
                            self.logger?.write("Error writing to MQTT: \(error.localizedDescription)")
                            SVProgressHUD.showErrorAndDismiss(withStatus: "Error: \(error.localizedDescription)", delay: 6)
                        }
                    }
                }
            }
        }
    }

    @IBAction func forceConnectToDevices(_ sender: Any) {
        //Try to connect to known devices
        logger?.write("Connecting to known sensors...")
        DispatchQueue.global(qos: .background).async {
            Scanner.shared.connectToKnownSensorsAndPostSummaryData() {
                Scanner.shared.logStatus()
            }
        }
    }
}
