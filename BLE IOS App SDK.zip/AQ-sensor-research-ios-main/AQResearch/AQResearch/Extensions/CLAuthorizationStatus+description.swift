//
//  CLAuthorizationStatus+description.swift
//  AQResearch
//
//  Created by Aaron on 1/3/20.
//  Copyright © 2020 Procter & Gamble. All rights reserved.
//

import Foundation
import CoreLocation

extension CLAuthorizationStatus {
    var description: String {
        switch self {
        case .authorizedAlways:
            return "Authorized Always"
        case .authorizedWhenInUse:
            return "Authorized When In Use"
        case .denied:
            return "Denied"
        case .notDetermined:
            return "Not Determined"
        case .restricted:
            return "Restricted"
        default:
            return "Unknown"
        }
    }
}
