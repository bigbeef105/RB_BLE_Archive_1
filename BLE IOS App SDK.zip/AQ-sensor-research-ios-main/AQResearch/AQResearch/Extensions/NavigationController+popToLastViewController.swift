//
//  NavigationViewController+popToLastWithType.swift
//  AQResearch
//
//  Created by Aaron on 1/23/20.
//  Copyright © 2020 Procter & Gamble. All rights reserved.
//

import Foundation
import UIKit

extension UINavigationController {
    /// Pops to the last view controller with the given type
    ///
    /// If no view controller of the given type exists in the stack, then no action is taken.
    ///
    /// - Parameters:
    ///   - type: The type of view controller to pop to
    ///   - animated: Defines whether the transition be animated
    func popToLastViewController<T>(with type: T.Type, animated: Bool) where T: UIViewController {
        if let vc = getLastViewController(with: type.self) {
            popToViewController(vc, animated: animated)
        }
    }
    
    /// Returns the topmost view controller with the given type
    ///
    /// Returns `nil` if no view controller of the given type exists in the stack
    ///
    /// - Parameter type: The type of view controller to retrieve
    func getLastViewController<T>(with type: T.Type) -> UIViewController? where T: UIViewController {
        for view in self.viewControllers.reversed() {
            if view is T {
                return view
            }
        }

        //No VCs of proper type in the stack
        return nil
    }
    
}
