//
//  URL+postAndForget.swift
//  BeaconBleTest
//
//  Created by Aaron on 12/13/19.
//  Copyright © 2019 Atomic Robot. All rights reserved.
//

import Foundation

extension URL {
    
    /// Performs a POST action with the given URL, ignoring the result
    /// - Parameters:
    ///   - body: The body of the HTTP POST request
    ///   - logger: Optional. The Logger to use
    ///   - completion: Optional. Called after the request completes.
    func postAndForget(withBody body: String? = nil, logger: Logger? = nil, completion: @escaping () -> Void = {}) {
        
        let configuration = URLSessionConfiguration.default
        let session = URLSession(configuration: configuration)
        
        //let url = NSURL(string: urlString as String)
        var request : URLRequest = URLRequest(url: self)
        request.httpMethod = "POST"
        request.httpBody = body?.data(using: .utf8)
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("application/json", forHTTPHeaderField: "Accept")

        let dataTask = session.dataTask(with: request) { _, _, _ in
            completion()
        }
        dataTask.resume()

    }
}


