//
//  AppDelegate+CLLocationManager.swift
//  BeaconBleTest
//
//  Created by Aaron on 12/26/19.
//  Copyright © 2019 Atomic Robot. All rights reserved.
//

import Foundation
import CoreLocation

extension AppDelegate: CLLocationManagerDelegate {

    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        Scanner.shared.startScanning()
    }

    func locationManager(_ manager: CLLocationManager, didEnterRegion region: CLRegion) {
        logger?.write("didEnterRegion: \(region.identifier)")
        guard let region = region as? CLBeaconRegion else { return }    //If we didn't enter a Beacon Region, do nothing.
        Event.Beacon.enteredRegion(region: region).log()
        DispatchQueue.global(qos: .background).async {
//            self.logger?.write("Connecting to known sensors...")
//            Scanner.shared.connectToKnownSensorsAndPostSummaryData()
            
            if let sensor = Scanner.shared.sensors.first(where: { sensor -> Bool in
                return sensor.beaconParams?.matches(region: region) ?? false
            }) {
                self.logger?.write("- didEnterRegion: Connecting to sensor: \(sensor.debugDescription)")
                Scanner.shared.connectAndPostSummaryData(toSensor: sensor) { result in
                    switch result {
                    case .failure(let error):
                        self.logger?.write("--- didEnterRegion:   Connect finished with error: \(error.localizedDescription)")
                    case .success:
                        self.logger?.write("--- didEnterRegion:   Connect finished successfully")
                    }
                }
            } else {
                self.logger?.write("- didEnterRegion: No sensor found for region: \(region.debugDescription)")
            }
        }
    }

    func locationManager(_ manager: CLLocationManager, didExitRegion region: CLRegion) {
        logger?.write("didExitRegion: \(region.identifier)")
        if let region = region as? CLBeaconRegion {
            Event.Beacon.exitedRegion(region: region).log()
        }
    }

    func locationManager(_ manager: CLLocationManager, didRangeBeacons beacons: [CLBeacon], in region: CLBeaconRegion) {
        if beacons.count > 0 {
            logger?.write("(\(Int.random(in: 0...9))) Found \(beacons.count) beacons")
        }
    }
}
