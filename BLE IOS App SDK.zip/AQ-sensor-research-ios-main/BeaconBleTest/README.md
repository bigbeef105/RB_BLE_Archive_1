# poc-base
Base for a proof-of-concept app in Swift
