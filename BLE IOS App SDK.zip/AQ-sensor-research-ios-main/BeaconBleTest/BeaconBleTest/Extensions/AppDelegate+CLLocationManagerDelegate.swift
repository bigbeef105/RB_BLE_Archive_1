//
//  AppDelegate+CLLocationManager.swift
//  BeaconBleTest
//
//  Created by Aaron on 12/26/19.
//  Copyright © 2019 Atomic Robot. All rights reserved.
//

import Foundation
import CoreLocation

extension AppDelegate: CLLocationManagerDelegate {

    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        if status == .authorizedAlways {
            startScanning(forUuid: "1F48215E-DFF1-41C1-8656-CD5D0E06A76D", major: 1, minor: 1, identifier: "AWT Blueberry 2")
            startScanning(forUuid: "1F48215E-DFF1-41C1-8656-CD5D0E06A76D", major: 1, minor: 2, identifier: "AWT Ice 2")
            startScanning(forUuid: "1F48215E-DFF1-41C1-8656-CD5D0E06A76D", major: 1, minor: 3, identifier: "AWT Mint 2")
            startScanning(forUuid: "1F48215E-DFF1-41C1-8656-CD5D0E06A76D", major: 1, minor: 4, identifier: "AWT Blueberry 1")
            startScanning(forUuid: "1F48215E-DFF1-41C1-8656-CD5D0E06A76D", major: 1, minor: 5, identifier: "AWT Ice 1")
            startScanning(forUuid: "1F48215E-DFF1-41C1-8656-CD5D0E06A76D", major: 1, minor: 6, identifier: "AWT Mint 1")
        } else {
            print("Not authorized to range/monitor for beacons. status: \(status)")
        }
    }
    
    func startScanning(forUuid uuid: String, major: CLBeaconMajorValue, minor: CLBeaconMinorValue, identifier: String) {
        let uuid = UUID(uuidString: uuid)!
        let beaconRegion = CLBeaconRegion(proximityUUID: uuid, major: major, minor: minor, identifier: identifier)
        beaconRegion.notifyEntryStateOnDisplay = true
       
        if CLLocationManager.isMonitoringAvailable(for: CLBeaconRegion.self) {

            logger?.write("Monitoring for beacons started: {uuid: \(uuid.uuidString.prefix(8)), major: \(major), minor: \(minor)}")
            locationManager.startMonitoring(for: beaconRegion)
        } else {
            print("Monitoring for beacons not available.")
        }
    }

    func locationManager(_ manager: CLLocationManager, didEnterRegion region: CLRegion) {
        logger?.write("didEnterRegion: \(region.identifier)")
        
        DispatchQueue.global(qos: .background).async {
            Scanner.connectToKnownDevices(logger: self.logger)
        }
    }

    func locationManager(_ manager: CLLocationManager, didExitRegion region: CLRegion) {
        logger?.write("didExitRegion: \(region.identifier)")
    }

    func locationManager(_ manager: CLLocationManager, didRangeBeacons beacons: [CLBeacon], in region: CLBeaconRegion) {
        if beacons.count > 0 {
            logger?.write("(\(Int.random(in: 0...9))) Found \(beacons.count) beacons")
        }
    }
}
