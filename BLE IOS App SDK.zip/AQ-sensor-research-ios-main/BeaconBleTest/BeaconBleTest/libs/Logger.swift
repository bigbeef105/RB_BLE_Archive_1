//
//  Logger.swift
//  AQWritePOC
//
//  Created by Aaron on 11/11/19.
//  Copyright © 2019 Alchemy. All rights reserved.
//

import Foundation

protocol Logger {
    func write(_ text: String?)
    func write(_ text: String?, channel: String)
    func write(_ text: String?, datetime: Date)
    func write(_ text: String?, datetime: Date, channel: String)
}

class MultiLogger: Logger {

    static let shared = MultiLogger()

    var loggerList: [Logger] = []

    private init() {
    }

    func addLogger(logger: Logger, clearAll: Bool = false) {
        addLoggers(loggers: [logger], clearAll: clearAll)
    }

    func addLoggers(loggers: [Logger], clearAll: Bool = false) {
        print("Adding Loggers.  clearAll: \(clearAll)")
        if clearAll {
            self.loggerList = loggers
        } else {
            loggerList.append(contentsOf: loggers)
        }
    }

    func write(_ text: String?) {
        for logger in loggerList {
            logger.write(text, datetime: Date())
        }
    }
    
    func write(_ text: String?, channel: String) {
        for logger in loggerList {
            logger.write(text, datetime: Date(), channel: channel)
        }
    }
    
    func write(_ text: String?, datetime: Date = Date()) {
        for logger in loggerList {
            logger.write(text, datetime: datetime)
        }
    }
    
    func write(_ text: String?, datetime: Date = Date(), channel: String) {
        for logger in loggerList {
            logger.write(text, datetime: datetime, channel: channel)
        }
    }
}

class ConsoleLogger: Logger {

    func write(_ text: String?) {
        print(text ?? "")
    }

    func write(_ text: String?, channel: String) {
        print("\(channel): \(text ?? "")")
    }
    
    func write(_ text: String?, datetime: Date = Date()) {
        print("[\(formatDate(datetime))]: \(text ?? "")")
    }
    
    func write(_ text: String?, datetime: Date = Date(), channel: String) {
        print("[\(formatDate(datetime))] [\(channel)] \(text ?? "")")
    }

    func formatDate(_ date: Date) -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateStyle = .full
        dateFormatter.timeZone = TimeZone.autoupdatingCurrent
        dateFormatter.locale = Locale.autoupdatingCurrent
        
        return dateFormatter.string(from: date)
    }
    
    
}

class WebLogger: Logger {

    struct LogEntry {
        let date: Date
        let text: String
        
        func toJsonString() -> String {
            
            let formatter = DateFormatter()
            formatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSSSS"
            let dateString = formatter.string(from: date)
            
            return """
            {
                "date": "\(dateString)",
                "text": "\(text.replacingOccurrences(of: "\"", with: "\\\""))"
            }
            """
        }
        
    }
    
    fileprivate let url: String
    fileprivate let logName: String

    func write(_ text: String?) {
        write("\(text ?? "")", datetime: Date(), channel: "")
    }
    
    func write(_ text: String?, datetime: Date) {
        write("\(text ?? "")", datetime: datetime, channel: "")
    }
   
    func write(_ text: String?, channel: String) {
        write("\(text ?? "")", datetime: Date(), channel: channel)
    }

    func write(_ text: String?, datetime: Date = Date(), channel: String) {
        
        let postLogName = "\(logName)\(channel != "" ? "-\(channel)" : "")"
        let url = URL(string: "\(self.url)\(postLogName)")
        
        let entry = LogEntry(date: datetime, text: text ?? "")
        let payload = entry.toJsonString()
        
        url?.postAndForget(withBody: payload)
    }

    init(logName: String? = nil) {
        self.logName = logName ?? "default"
        url = "https://logger.tylerinternet.com/Log/"
    }
}
