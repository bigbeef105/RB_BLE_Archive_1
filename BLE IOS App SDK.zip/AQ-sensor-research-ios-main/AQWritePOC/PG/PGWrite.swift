//
//  PGWrite.swift
//  AQWritePOC
//
//  Created by Aaron on 11/7/19.
//  Copyright © 2019 Alchemy. All rights reserved.
//

import Foundation
import AWSIoT

struct ProvisioningPayload {
    let deviceType: String
    let serialNumber: String

    func getJson() -> String {
        return """
        {
            "deviceType": "\(deviceType)",
            "serialNumber": "\(serialNumber)"
        }
        """
    }
}

struct DeviceDataPayload {
    let deviceType: String
    let serialNumber: String

    func getJson() -> String {
        return """
        {
            "deviceType": "\(deviceType)",
            "serialNumber": "\(serialNumber)"
        }
        """
    }
}

class PGWrite {

    fileprivate static let ProvisionUrl = URL(string: "https://yzcsmh6wr1.execute-api.us-east-1.amazonaws.com/api/v1/provision")!
    fileprivate static let IoTEndpoint = "wss://a1z2xigbhrq71i-ats.iot.us-east-1.amazonaws.com/mqtt"
    fileprivate static let DataManagerKey = "MyAWSIoTDataManager"
    fileprivate static let AppClientId = "7l6327mincc632o91d3qr493an"
    fileprivate static let IdentityPoolId = "us-east-1:cae961ca-cc4c-4156-b29f-6c261118ad01"
    fileprivate static let CognitoPoolId = "us-east-1_2MjhVtNvl"
    fileprivate static let CertificateId = "b8fa8cc4e4cdb65a8069ecfdde0d7904383aef90146a4aaa73ae7ad19307447f"

    static let shared = PGWrite()

    var endpoint: AWSEndpoint
    var credentialsProvider: AWSCognitoCredentialsProvider
    var dataConfiguration: AWSServiceConfiguration
    var status: AWSIoTMQTTStatus? { dataManager?.getConnectionStatus() }
    var logger: Logger?
    var dataManager: AWSIoTDataManager?

    fileprivate init() {
        endpoint = AWSEndpoint(urlString: PGWrite.IoTEndpoint)
//        credentialsProvider = AWSCognitoCredentialsProvider(regionType: .USEast1, identityPoolId: PGWrite.CognitoPoolId, identityProviderManager: PGAuth.shared.awsMobileClient)
//        credentialsProvider = AWSCognitoCredentialsProvider(regionType:.USEast1, identityPoolId: PGWrite.IdentityPoolId)
        credentialsProvider = PGAuth.shared.awsMobileClient
        dataConfiguration = AWSServiceConfiguration(region:.USEast1, endpoint: endpoint, credentialsProvider: credentialsProvider)
        AWSServiceManager.default().defaultServiceConfiguration = dataConfiguration
        AWSIoTDataManager.register(with: dataConfiguration, forKey: PGWrite.DataManagerKey)
        dataManager = AWSIoTDataManager(forKey: PGWrite.DataManagerKey)

        dataManager?.register(withShadow: "research_bit_test1", options: nil, eventCallback: { (str, opType, stType, str2, data) in
            self.logger?.write("\(#function) - Register Callback: \(str):\(opType):\(stType):\(str2):\(String(bytes: data, encoding: .utf8))")
        })
    }

    func configure(logger: Logger) {
        self.logger = logger
    }

    func provisionDevice(payload: ProvisioningPayload, auth: PGAuth = PGAuth.shared, completion: () -> Void) {

        logger?.write("Writing data...")

        auth.getTokens { tokens in

            if let token = tokens?.accessToken?.tokenString {

                self.logger?.write("Found token: \(token)")

                let url = PGWrite.ProvisionUrl
                var request = URLRequest(url: url)

                request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
                request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
                request.httpMethod = "POST"

                request.httpBody = payload.getJson().data(using: .utf8)

                let task = URLSession.shared.dataTask(with: request) { data, response, error in
                    guard let data = data,
                        let response = response as? HTTPURLResponse,
                        error == nil else {                                              // check for fundamental networking error
                            self.logger?.write("error: \(error.debugDescription)")
                            return
                        }

                    guard (200 ... 299) ~= response.statusCode else {                    // check for http errors
                        self.logger?.write("statusCode should be 2xx, but is \(response.statusCode)")
                        self.logger?.write("response = \(response)")
                        if let responseString = String(data: data, encoding: .utf8) {
                            self.logger?.write("responseString = \(responseString)")
                        }
                        return
                    }

                    if let responseString = String(data: data, encoding: .utf8) {
                        self.logger?.write("responseString = \(responseString)")
                    } else {
                        self.logger?.write("No body returned.")
                    }
                }

                task.resume()
            } else {
                //No Token.  Need to login again
            }
        }
    }

    func connect(auth: PGAuth = PGAuth.shared, completion: () -> Void) {
        
        guard let dataManager = dataManager else {
            self.logger?.write("*****\nNo dataManager!\n*****")
            return
        }
        
        let credentialsTask = dataManager.configuration.credentialsProvider.credentials()
        let identityIdTask  = PGAuth.shared.awsMobileClient.getIdentityId()
        
        credentialsTask.waitUntilFinished()
        identityIdTask.waitUntilFinished()
        
        let credentials = credentialsTask.result
        let identityId  = identityIdTask.result


        logger?.write("---------------------")
        logger?.write("Identity Id: \(identityId ?? "nil")")
        logger?.write("Credentials: \(credentials?.accessKey ?? "nil")")
        logger?.write("---------------------")

        let success1 = dataManager.connectUsingWebSocket(withClientId: PGWrite.AppClientId, cleanSession: true) { status in
            self.logger?.write("***** Web Socket Connection callback status = \(self.describeConnectionStatus(status))")
        }
        logger?.write("Finished Web Socket connect - success: \(success1)")
    }

    func subscribe(to topic: PGMqttThingTopic, auth: PGAuth = PGAuth.shared, completion: (_ message: String) -> Void) {
        guard let dataManager = dataManager else {
            logger?.write("No dataManager!")
            return
        }

        let connection = dataManager.getConnectionStatus()

        guard connection == .connected else {
            logger?.write("\(#function): Not connected: \(describeConnectionStatus(connection))")
            return
        }
        
        //TODO: Actually do the subscribe...
        
    }

    func unsubscribe(from topic: PGMqttThingTopic, auth: PGAuth = PGAuth.shared, completion: (() -> Void)?) {

    }

    func writeData(to topic: PGMqttThingTopic, responseTopics: [PGMqttThingTopic]?, payload: DeviceDataPayload, auth: PGAuth = PGAuth.shared, completion: () -> Void) {

        guard let dataManager = dataManager else {
            logger?.write("No dataManager!")
            return
        }

        let connection = dataManager.getConnectionStatus()

        guard connection == .connected else {
            logger?.write("\(#function): Not connected: \(describeConnectionStatus(connection))")
            logger?.write("** Error: \(dataManager.configuration.credentialsProvider.credentials().error?.localizedDescription ?? "nil")")
            return
        }

        if let rt = responseTopics {
            for topic in rt {
                dataManager.subscribe(toTopic: topic.getTopic(), qoS: .messageDeliveryAttemptedAtLeastOnce) { (data) in
                    self.logger?.write("***** Data Received *****")
                    self.logger?.write(String(bytes: data, encoding: .utf8) ?? "-None-")
                    self.logger?.write("***** End Received  *****")
                }
            }
        }

        logger?.write("Writing Data - status: \(dataManager.getConnectionStatus().rawValue)")

        let success = dataManager.publishString("{\"message\": \"AWT Test String\"}", onTopic: topic.getTopic(), qoS:.messageDeliveryAttemptedAtLeastOnce)
        logger?.write("Published to topic: \(success)")

        let status = dataManager.getConnectionStatus()
        logger?.write("Connection Status (last): \(describeConnectionStatus(status))")

    }

    func disconnect() {
        let connection = dataManager?.getConnectionStatus()
        if let dataManager = dataManager, connection == .connected || connection == .connecting {
            dataManager.disconnect()
        } else {
            logger?.write("Not connected: \(connection != nil ? describeConnectionStatus(connection!) : "nil")")
        }
    }

    
    func describeConnectionStatus(_ status: AWSIoTMQTTStatus) -> String {
        switch status {
        case .unknown:
            return "Unknown"
        case .connecting:
            return "Connecting"
        case .connected:
            return "Connected"
        case .disconnected:
            return "Disconnected"
        case .connectionRefused:
            return "ConnectionRefused"
        case .connectionError:
            return "ConnectionError"
        case .protocolError:
            return "ProtocolError"
        }
    }
    
}
