//
//  CognitoAbstraction.swift
//  AQWritePOC
//
//  Created by Aaron on 11/6/19.
//  Copyright © 2019 Alchemy. All rights reserved.
//

import Foundation
import AWSMobileClient
import AWSAuthUI

public class PGAuth {

    static var shared: PGAuth = PGAuth()

    fileprivate var mobileClient: AWSMobileClient!
    fileprivate var isConfigured: Bool = false
    fileprivate var authUiConfig: SignInUIOptions!
    fileprivate var hostedUiConfig: HostedUIOptions?

    var awsMobileClient: AWSMobileClient {
        return mobileClient
    }

    var logger: Logger?

    var authState: UserState {
        return mobileClient.currentUserState
    }

    var tokens: Tokens?

    private init() {
        configure()
    }

    func setLogger(logger: Logger) {
        self.logger = logger
    }

    func configure() {

        //Configuration should only be called once
        guard isConfigured == false else {
            return
        }

        mobileClient = AWSMobileClient.default()

        print("Configuring PGAuth...")

        //Print login state changes to the console
        //TODO: Remove this, or alter to re-authenticate when needed
        mobileClient.addUserStateListener(self) { (userState, info) in
            switch (userState) {
            case .guest:
                print("***** user is in guest mode.")
            case .signedOut:
                print("***** user signed out")
            case .signedIn:
                print("***** user is signed in.")
            case .signedOutUserPoolsTokenInvalid:
                print("***** need to login again.")
            case .signedOutFederatedTokensInvalid:
                print("***** user logged in via federation, but currently needs new tokens")
            default:
                print("***** unsupported")
            }

            self.mobileClient.getTokens { (tokens, error) in
                self.tokens = tokens
                print("Tokens: \(tokens)")
                print("Error: \(error)")
            }

        }

        mobileClient.initialize { (userState, error) in
            if let userState = userState {
                switch(userState){
                case .signedIn:
                    print("***** Logged In")
                case .signedOut:
                    print("***** Not Signed In")
                default:
                    self.mobileClient.signOut()
                }
            } else if let error = error {
                print(error.localizedDescription)
            }
        }

        authUiConfig = SignInUIOptions(canCancel: true, logoImage: UIImage(named: "pglogo"), backgroundColor: nil, secondaryBackgroundColor: nil, primaryColor: nil, disableSignUpButton: false)
        isConfigured = true
    }

    func presentSignUpIn(navigationController: UINavigationController, completion: @escaping ((UserState?, Error?) -> Void) = {_,_ in }) {
        mobileClient.showSignIn(navigationController: navigationController, signInUIOptions: authUiConfig, hostedUIOptions: hostedUiConfig, completion)
    }

    func signOut(completion: ((Error?) -> Void)? = nil) {
        if let completion = completion {
            mobileClient.signOut(completionHandler: completion)
        } else {
            mobileClient.signOut()
        }
    }

    func getTokens(completion: @escaping (Tokens?) -> Void) {
        print("Called getTokens(completion:)")
        if self.authState == .signedIn && tokens != nil {
            print("Tokens exist. Passing them to completion.")
            completion(self.tokens)
            return
        }

        print("Tokens don't exist yet.  Getting them.")

        mobileClient.getTokens { (tokens, error) in
            if let error = error {
                print("Error retrieving tokens: \(error)")
                self.tokens = nil
                completion(self.tokens)
            } else {
                print("Tokens retrieved: \(tokens)")
                self.tokens = tokens
                completion(self.tokens)
            }
        }
    }

    func getTokens() -> Tokens? {
        print("Called getTokens()")
        if self.authState == .signedIn && tokens != nil {
            print("Tokens exist. Returning them.")
            return tokens!
        }
        print("Tokens don't exist yet.  Getting them.")

        let semaphore = DispatchSemaphore(value: 1)

        mobileClient.getTokens { (tokens, error) in
            if let error = error {
                print("Error: \(error)")
                self.tokens = nil
            } else {
                print("Tokens retrieved: \(tokens)")
                self.tokens = tokens
            }

            semaphore.signal()
        }

        _ = semaphore.wait(timeout: .now() + 5.0)   //Wait up to 5 seconds for getTokens to finish

        return self.tokens
    }
}
