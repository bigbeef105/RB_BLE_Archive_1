//
//  PGMqtt.swift
//  AQWritePOC
//
//  Created by Aaron on 11/25/19.
//  Copyright © 2019 Alchemy. All rights reserved.
//

import Foundation

enum PGMqttThingTopic {
    case updateShadow(thingId: String)           //  $aws/things/research_bit_test1/shadow/update
    case updateShadowAccepted(thingId: String)   //  $aws/things/research_bit_test1/shadow/update/accepted
    case updateShadowDocuments(thingId: String)  //  $aws/things/research_bit_test1/shadow/update/documents
    case updateShadowRejected(thingId: String)   //  $aws/things/research_bit_test1/shadow/update/rejected
    case getShadow(thingId: String)              //  $aws/things/research_bit_test1/shadow/get
    case getShadowAccepted(thingId: String)      //  $aws/things/research_bit_test1/shadow/get/accepted
    case getShadowRejected(thingId: String)      //  $aws/things/research_bit_test1/shadow/get/rejected
    case deleteShadow(thingId: String)           //  $aws/things/research_bit_test1/shadow/delete
    case deleteShadowAccepted(thingId: String)   //  $aws/things/research_bit_test1/shadow/delete/accepted
    case deleteShadowRejected(thingId: String)   //  $aws/things/research_bit_test1/shadow/delete/rejected
    case testId(thingId: String)                 //  awt_test_topic/research_bit_test1
    case test                                    //  awt_test_topic


    func getTopic() -> String {
        switch self {
        case let .updateShadow(thingId):
            return "$aws/things/\(thingId)/shadow/update"
        case let .updateShadowAccepted(thingId):
            return "$aws/things/\(thingId)/shadow/update/accepted"
        case let .updateShadowDocuments(thingId):
            return "$aws/things/\(thingId)/shadow/update/documents"
        case let .updateShadowRejected(thingId):
            return "$aws/things/\(thingId)/shadow/update/rejected"
        case let .getShadow(thingId):
            return "$aws/things/\(thingId)/shadow/get"
        case let .getShadowAccepted(thingId):
            return "$aws/things/\(thingId)/shadow/get/accepted"
        case let .getShadowRejected(thingId):
            return "$aws/things/\(thingId)/shadow/get/rejected"
        case let .deleteShadow(thingId):
            return "$aws/things/\(thingId)/shadow/delete"
        case let .deleteShadowAccepted(thingId):
            return "$aws/things/\(thingId)/shadow/delete/accepted"
        case let .deleteShadowRejected(thingId):
            return "$aws/things/\(thingId)/shadow/delete/rejected"
        case let .testId(thingId):
            return "awt_test_topic/\(thingId)"
        case .test:
            return "awt_test_topic"
        }
    }

}
